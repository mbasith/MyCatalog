#! /usr/bin/python3

import os
import sys

from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine


Base = declarative_base()


class genre(Base):
    # Table
    __tablename__ = 'genre'

    # Mapper
    name = Column(String(80), nullable=False)
    id = Column(Integer, primary_key=True)

    @property
    def serialize(self):
        # Returns object data in easily serializable format
        return {
            'name': self.name,
            'id': self.id,
        }


class game(Base):
    # Table
    __tablename__ = 'game_item'

    # Mapper
    name = Column(String(80), nullable=False)
    id = Column(Integer, primary_key=True)
    course = Column(String(250))
    description = Column(String(250))
    price = Column(String(8))
    genre_id = Column(Integer, ForeignKey('genre.id'))
    genre = relationship(genre)

    @property
    def serialize(self):
        # Returns object data in easily serializable format
        return {
            'name': self.name,
            'description': self.description,
            'id': self.id,
            'price': self.price,
            'course': self.course
        }

# End Code
# Create instance of engine class and point to DB being used
engine = create_engine('sqlite:///genregame.db')
# Adds classes in our database
Base.metadata.create_all(engine)

